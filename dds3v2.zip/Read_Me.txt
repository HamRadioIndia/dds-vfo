_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

		DDS 3.2

_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

A higly stable VFO based on DDS (Direct Digital Synthesizer) technology. The frequency range is from 0 to 80MHz. The main features are: Direct Frequency entry using Keypad, CW/LSB/USB mods and band selection out puts are provided. It uses PIC16F628 and AD9850/51 and a two line LCD Display

Bug Fixed
=========
1. The 10MHz out put in Calibration has been corrected.

Changes
========
No other changes with DDS 3.1

This ZIP file includes
======================
1. A Read me file (this file)
2. dds3v2_ckt.pdf ( Circuit of this project )
3. dds3v2.pdf ( Description )
4. dds3v2.HEX (Hex file for programming PIC16F628A)
5. dds3v2A.HEX (Hex file for programming PIC16F628A, with different bands)

The dds3v1.HEX file has original band selections as DDS 2.0,i.e as follows (on LCD the version no will be displayed as 3.0x).

Band 1 -> 0 to 10 MHz 
Band 2 -> 10 to 17 MHz
Band 3 -> 17 to 25 MHz
Band 4 -> Above 25 MHz

The dds3v1A.HEX file has following band selections (on LCD the version no will be displayed as 3.0xA).

Band 1 -> 0 to 2.5 MHz 
Band 2 -> 2.5 to 5.2 MHz
Band 3 -> 5.2 to 7.5 MHz
Band 4 -> Above 7.5 MHz

Note:- The bands are selected based on the Display frequency, not DDS O/P frequency; both are different if you set a display offset.

Here is PIC Programmer
======================

http://www.hamradioindia.org/circuits/feng.php

For PCB designs visit Announcements in HamRadioIndia Forums
======================
 
http://www.hamradioindia.org/forums

For further helps, please use HamRadioIndia Forums
======================

http://www.hamradioindia.org/forums

73's
VU3CNS


